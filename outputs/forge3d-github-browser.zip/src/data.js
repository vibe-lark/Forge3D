const khronos = 'KhronosGroup/glTF-Sample-Assets';
const branch = 'main';
const commitSha = '2bac6f8c57bf471df0d2a1e8a8ec023c7801dddf';

function asset({ id, name, category, path, size, license, attribution }) {
  const encodedPath = path.split('/').map(encodeURIComponent).join('/');
  const modelDirectory = encodeURIComponent(path.split('/')[1]);
  return {
    id,
    name,
    category,
    format: path.toLowerCase().endsWith('.glb') ? 'GLB' : 'glTF',
    path,
    size,
    license,
    attribution,
    repo: khronos,
    branch,
    commitSha,
    stars: 993,
    updated: '2026',
    description: 'Khronos glTF Sample Assets 中的真实模型文件。',
    rawUrl: `https://raw.githubusercontent.com/${khronos}/${commitSha}/${encodedPath}`,
    sourceUrl: `https://github.com/${khronos}/blob/${commitSha}/${encodedPath}`,
    repoUrl: `https://github.com/${khronos}`,
    licenseUrl: `https://github.com/${khronos}/blob/${commitSha}/Models/${modelDirectory}/LICENSE.md`,
    trusted: true,
  };
}

export const curatedAssets = [
  asset({
    id: 'car-concept',
    name: 'Car Concept',
    category: '汽车',
    path: 'Models/CarConcept/GLB/CarConcept.glb',
    size: 10267996,
    license: 'CC BY 4.0 + 商标说明',
    attribution: 'Eric Chadwick / DGG；含 Khronos 与 3D Commerce 标志。',
  }),
  asset({
    id: 'toy-car',
    name: 'Toy Car',
    category: '汽车',
    path: 'Models/ToyCar/glTF-Binary/ToyCar.glb',
    size: 5422412,
    license: 'CC0 1.0',
    attribution: 'Guido Odendahl / Eric Chadwick。',
  }),
  asset({
    id: 'antique-camera',
    name: 'Antique Camera',
    category: '相机',
    path: 'Models/AntiqueCamera/glTF-Binary/AntiqueCamera.glb',
    size: 17540348,
    license: 'CC0 1.0',
    attribution: '© UX3D，模型以 CC0 发布；品牌标识另有说明。',
  }),
  asset({
    id: 'chronograph-watch',
    name: 'Chronograph Watch',
    category: '产品',
    path: 'Models/ChronographWatch/glTF-Binary/ChronographWatch.glb',
    size: 7446368,
    license: 'CC BY 4.0',
    attribution: '基于 graphiccompressor 的 Chronograph Watch Mudmaster。',
  }),
  asset({
    id: 'boom-box',
    name: 'Boom Box',
    category: '产品',
    path: 'Models/BoomBox/glTF-Binary/BoomBox.glb',
    size: 10614184,
    license: 'CC0 1.0',
    attribution: 'Khronos glTF Sample Assets / Public。',
  }),
  asset({
    id: 'commercial-refrigerator',
    name: 'Commercial Refrigerator',
    category: '机械',
    path: 'Models/CommercialRefrigerator/glTF-Binary/CommercialRefrigerator.glb',
    size: 10131180,
    license: 'CC BY 4.0',
    attribution: '基于 Sean Thomas 的 Commercial Fridge。',
  }),
  asset({
    id: 'water-bottle',
    name: 'Water Bottle',
    category: '产品',
    path: 'Models/WaterBottle/glTF-Binary/WaterBottle.glb',
    size: 8966700,
    license: 'CC0 1.0',
    attribution: 'Microsoft，以 CC0 发布。',
  }),
  asset({
    id: 'materials-variants-shoe',
    name: 'Materials Variants Shoe',
    category: '产品',
    path: 'Models/MaterialsVariantsShoe/glTF-Binary/MaterialsVariantsShoe.glb',
    size: 7833592,
    license: 'CC BY 4.0',
    attribution: 'Shopify；包含 KHR_materials_variants。',
  }),
  asset({
    id: 'cesium-milk-truck',
    name: 'Cesium Milk Truck',
    category: '汽车',
    path: 'Models/CesiumMilkTruck/glTF-Binary/CesiumMilkTruck.glb',
    size: 369980,
    license: 'CC BY + 商标说明',
    attribution: 'Cesium；使用时需保留署名并注意商标限制。',
  }),
  asset({
    id: 'sunglasses-khronos',
    name: 'Sunglasses',
    category: '产品',
    path: 'Models/SunglassesKhronos/glTF-Binary/SunglassesKhronos.glb',
    size: 371188,
    license: 'CC BY 4.0 + 商标说明',
    attribution: 'Eric Chadwick / DGG；含 Khronos 与 3D Commerce 标志。',
  }),
];

export const categories = ['全部', '汽车', '相机', '机械', '产品'];

export const queryAliases = {
  汽车: 'car vehicle automotive',
  车: 'car vehicle automotive',
  相机: 'camera photography',
  摄像机: 'camera photography',
  零件: 'mechanical part industrial',
  机械: 'mechanical part industrial',
  产品: 'product configurator object',
  手表: 'watch product',
};
